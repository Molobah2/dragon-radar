import asyncio
from playwright.async_api import async_playwright
U='file:///tmp/claude-0/-home-claude/0370a9bc-09aa-5c0e-9bd4-b8c8dd3e00e9/scratchpad/fight/test.html'
async def run():
  async with async_playwright() as p:
    b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1280,'height':720});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(U);await pg.wait_for_timeout(400);await pg.click('#pick-tide');await pg.click('[data-l="2"]');await pg.click('#go')
    # player mashes random inputs for 40 s against the Hard computer
    import random
    keys=['KeyA','KeyD','KeyW','KeyS','KeyJ','KeyK','KeyL','KeyI']
    mind=9999;maxp=0;states=set()
    for i in range(150):
      k=random.choice(keys);await pg.keyboard.down(k);await pg.wait_for_timeout(random.randint(40,220));await pg.keyboard.up(k)
      st=await pg.evaluate("[__clash.state,Math.abs(__clash.fighters[0].x-__clash.fighters[1].x),__clash.fighters.every(f=>f.ground),__clash.partsCount,__clash.fighters.map(f=>f.x>=110&&f.x<=1490).every(Boolean)]")
      states.add(st[0]);maxp=max(maxp,st[3])
      if st[0]=='fight' and st[2]:mind=min(mind,st[1])
      if not st[4]:print('OUT OF BOUNDS',st)
      if st[0]=='end':break
    print('states seen',sorted(states),'min grounded distance',round(mind),'max particles',maxp,'errs',errs)
    await b.close()
asyncio.run(run())
