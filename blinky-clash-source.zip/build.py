import sys,base64,json,os
src,assets,out=sys.argv[1:4]
s=open(src).read()
A={}
for f in sorted(os.listdir(assets)):
    if f.endswith('.webp'):
        A[f[:-5]]='data:image/webp;base64,'+base64.b64encode(open(os.path.join(assets,f),'rb').read()).decode()
meta=json.load(open(os.path.join(assets,'meta.json')))
s=s.replace('/*ASSETS*/{}/*END*/','/*ASSETS*/'+json.dumps(A)+'/*END*/').replace('/*META*/{}/*ENDMETA*/','/*META*/'+json.dumps(meta)+'/*ENDMETA*/')
open(out,'w').write(s);print(out,len(s))
