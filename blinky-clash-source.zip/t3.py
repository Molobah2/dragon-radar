import asyncio
from playwright.async_api import async_playwright
U='file:///tmp/claude-0/-home-claude/0370a9bc-09aa-5c0e-9bd4-b8c8dd3e00e9/scratchpad/fight/test.html'
async def run():
  async with async_playwright() as p:
    b=await p.chromium.launch();errs=[]
    for name,vp,duo in [('pp',(390,844),False),('pl',(844,390),False),('pd',(844,390),True)]:
      ctx=await b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=True,is_mobile=True,device_scale_factor=2)
      pg=await ctx.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
      await pg.goto(U);await pg.wait_for_timeout(600)
      if name=='pp':await pg.screenshot(path='m_menu.png')
      if duo:await pg.tap('#m-duo')
      await pg.tap('#go');await pg.wait_for_timeout(2000)
      # tap punch button a few times
      for i in range(3):
        await pg.tap('.pb.punch');await pg.wait_for_timeout(200)
      await pg.screenshot(path=f'm_{name}.png')
      st=await pg.evaluate('JSON.stringify(__clash.fighters.map(f=>[Math.round(f.x),f.st,Math.round(f.meter)]))');print(name,st)
      await ctx.close()
    print('errs',errs)
    await b.close()
asyncio.run(run())
