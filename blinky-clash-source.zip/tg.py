import asyncio, io, json
import numpy as np
from PIL import Image
from playwright.async_api import async_playwright
U='file:///tmp/claude-0/-home-claude/0370a9bc-09aa-5c0e-9bd4-b8c8dd3e00e9/scratchpad/fight/test.html'
POSES={
 'idle':"f.st='idle';f.atk=null",
 'walk_a':"f.st='walk';f.vx=300*f.face;f.walkPh=0.9",
 'walk_b':"f.st='walk';f.vx=300*f.face;f.walkPh=2.3",
 'walk_c':"f.st='walk';f.vx=300*f.face;f.walkPh=4.0",
 'block':"f.st='block'",
 'punch':"f.st='punch';f.atk={type:'punch',t:.1,phase:'act',hit:false}",
 'kick':"f.st='kick';f.atk={type:'kick',t:.15,phase:'act',hit:false}",
 'cast':"f.st='special';f.atk={type:'special',t:.1,phase:'start',fired:true}",
 'hit':"f.st='hit';f.stun=1",
 'ko_lying':"f.ko=true;f.st='ko';f.koRot=-1.25*f.face",
 'land_squash':"f.sq=.16",
}
async def run():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    pg=await b.new_page(viewport={'width':1600,'height':900})
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(U);await pg.wait_for_timeout(500)
    await pg.click('#m-duo');await pg.click('#go');await pg.wait_for_timeout(1900)
    await pg.keyboard.press('Escape');await pg.evaluate("document.getElementById('pausel').hidden=true;__clash.DBG.noShadow=true;__clash.DBG.plainBg=true;__clash.DBG.fixedCam=true")
    v=await pg.evaluate("JSON.stringify(__clash.view)");print('view',v)
    async def shot():
      return np.asarray(Image.open(io.BytesIO(await pg.screenshot())).convert('RGB')).astype(int)
    reset="F.forEach(f=>{f.st='idle';f.atk=null;f.ko=false;f.koRot=0;f.stun=0;f.sq=0;f.vx=0;f.walkPh=0;f.y=__clash.GROUND;f.ground=true;f.hitFlash=0})"
    await pg.evaluate(f"(()=>{{const F=__clash.fighters;{reset};F[0].x=-900;F[1].x=-900}})()")
    await pg.wait_for_timeout(80);bg=await shot()
    res={}
    for side in ['left','right']:
      for name,code in POSES.items():
        await pg.evaluate(f"(()=>{{const F=__clash.fighters;{reset};F[0].x=-900;F[1].x=-900;const f=F[{0 if side=='left' else 1}];f.x={500 if side=='left' else 1100};f.face={1 if side=='left' else -1};{code}}})()")
        await pg.wait_for_timeout(60);im=await shot()
        d=np.abs(im-bg).sum(-1)>30
        x0=200 if side=='left' else 800;x1=x0+600
        win=d[150:820,x0:x1];rows=np.where(win.sum(1)>=3)[0]
        low=150+rows.max() if len(rows) else None
        vv=await pg.evaluate("[__clash.view.oy,__clash.view.s]");res[f"{side}:{name}"]=round(int(low)-(vv[0]+742*vv[1]),1) if low is not None else None
        if name in('idle','walk_b','ko_lying','punch'):Image.fromarray(im[400:800,x0:x1].astype(np.uint8)).save(f'g_{side}_{name}.png')
    print(json.dumps(res));print('errs',errs)
    await b.close()
asyncio.run(run())
