import asyncio, json, sys
from playwright.async_api import async_playwright
U='file:///tmp/claude-0/-home-claude/0370a9bc-09aa-5c0e-9bd4-b8c8dd3e00e9/scratchpad/fight/test.html'
# cases: (victim index, attacker x, victim x, key that attacks) ; attacker = other player
CASES=[('tide_KOd_toward_right_wall',1,1250,1400,'KeyG'),('tide_KOd_toward_left_wall',1,330,180,'KeyG'),
       ('ember_KOd_toward_right_wall',0,1250,1400,'Period'),('ember_KOd_toward_left_wall',0,330,180,'Period'),
       ('tide_KOd_midstage_by_punch',1,760,900,'KeyF')]
async def run():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    pg=await b.new_page(viewport={'width':1280,'height':720});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(U);await pg.wait_for_timeout(400);await pg.click('#m-duo');await pg.click('#go')
    F="__clash.fighters";report={}
    for ci,(name,vic,ax,vx,key) in enumerate(CASES):
      # wait for a live round
      for _ in range(60):
        if await pg.evaluate("__clash.state")=='fight':break
        await pg.wait_for_timeout(100)
      att=1-vic
      await pg.evaluate(f"(()=>{{const F={F};F.forEach(f=>{{f.vx=0;f.atk=null;f.st='idle';f.stun=0;f.wins=0}});F[{att}].x={ax};F[{vic}].x={vx};F[{vic}].hp=4;F[{att}].hp=100}})()")
      await pg.wait_for_timeout(120)
      await pg.evaluate("""(()=>{const F=__clash.fighters;window.KL=[];const t0=performance.now();(function rec(){const E=F[%d],ex=__clash.bodyExtent(E);
        KL.push({t:Math.round(performance.now()-t0),st:__clash.state,x:Math.round(E.x),y:Math.round(E.y),g:E.ground,ko:E.ko,ph:E.koPhase,rot:+(E.koRot||0).toFixed(2),lo:ex?Math.round(E.x+ex[0]):null,hi:ex?Math.round(E.x+ex[1]):null,timer:__clash.timer,hpA:F[%d].hp,wins:F.map(f=>f.wins)});
        if(performance.now()-t0<4200)requestAnimationFrame(rec)})()})()"""%(vic,att))
      await pg.keyboard.press(key)
      shots=[]
      for i,t in enumerate([200,500,900,1500,2300]):
        await pg.wait_for_timeout(t-([0,200,500,900,1500][i]));await pg.screenshot(path=f'K{ci}_{i}.png')
      # try to keep attacking the defeated fighter and the attacker during the K.O.
      await pg.keyboard.press('KeyF');await pg.keyboard.press('Period');await pg.keyboard.press('KeyH')
      await pg.wait_for_timeout(2100)
      L=await pg.evaluate("KL")
      ko=[r for r in L if r['ko']]
      first_ground=next((r['t'] for r in ko if r['g'] and r['ph']=='down'),None)
      down=[r for r in ko if r['ph']=='down']
      report[name]={'K.O. at ms':ko[0]['t'] if ko else None,'phases':list(dict.fromkeys(r['ph'] for r in ko)),'settled_on_floor_at_ms':first_ground,
        'final_lying':ko[-1] if ko else None,'max_body_right':max((r['hi'] for r in ko if r['hi'] is not None),default=None),'min_body_left':min((r['lo'] for r in ko if r['lo'] is not None),default=None),
        'all_down_frames_on_floor':all(r['y']==742 and r['g'] for r in down),'timer_values_during_ko':sorted(set(r['timer'] for r in L if r['st']=='ko')),
        'attacker_hp_during_ko':sorted(set(r['hpA'] for r in L if r['st']=='ko')),'states':list(dict.fromkeys(r['st'] for r in L)),'wins_end':L[-1]['wins']}
    print(json.dumps(report,indent=1));print('errs',errs);await b.close()
asyncio.run(run())
