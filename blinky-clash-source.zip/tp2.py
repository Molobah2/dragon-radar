import asyncio, json
from playwright.async_api import async_playwright
U='file:///tmp/claude-0/-home-claude/0370a9bc-09aa-5c0e-9bd4-b8c8dd3e00e9/scratchpad/fight/test.html'
R={}
async def run():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    pg=await b.new_page(viewport={'width':1600,'height':900});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(U);await pg.wait_for_timeout(400);await pg.click('#m-duo');await pg.click('#go');await pg.wait_for_timeout(1900)
    ev=pg.evaluate;F="__clash.fighters"
    async def place(x0,x1,extra=""):
      await ev(f"(()=>{{const F={F};F.forEach(f=>{{f.atk=null;f.stun=0;f.vx=0;f.vy=0;f.y=742;f.ground=true;f.st='idle';f.hp=100;f.cool=0;f.meter=0}});F[0].x={x0};F[1].x={x1};{extra}}})()");await pg.wait_for_timeout(120)
    # facing
    await place(600,1000);R['facing']=await ev(f"{F}.map(f=>f.face)")
    await place(1100,500);R['facing_swapped']=await ev(f"{F}.map(f=>f.face)")
    # direction of hits, both sides
    await place(900,1060);await pg.keyboard.press('KeyF');await pg.wait_for_timeout(260)
    R['p1_punch_from_left [hp, push dir, face]']=await ev(f"[{F}[1].hp,Math.sign({F}[1].vx)||'still',{F}[0].face]")
    await place(1060,900);await pg.keyboard.press('KeyF');await pg.wait_for_timeout(260)
    R['p1_punch_from_right']=await ev(f"[{F}[1].hp,Math.sign({F}[1].vx)||'still',{F}[0].face]")
    await place(1060,900);await pg.keyboard.press('Period');await pg.wait_for_timeout(320)
    R['p2_kick_from_left']=await ev(f"[{F}[0].hp,Math.sign({F}[0].vx)||'still',{F}[1].face]")
    # spacing: walk into each other for 1.2 s
    await place(700,900);await pg.keyboard.down('KeyD');await pg.keyboard.down('ArrowLeft')
    mins=[]
    for i in range(12):
      await pg.wait_for_timeout(100);mins.append(await ev(f"Math.round(Math.abs({F}[0].x-{F}[1].x))"))
    await pg.keyboard.up('KeyD');await pg.keyboard.up('ArrowLeft');R['walk_into_each_other_distance']=mins
    # wall: defender cornered on the right, attacker gets pushed back
    await place(1340,1480);x0=await ev(f"{F}[0].x")
    for k in range(3):
      await pg.keyboard.press('KeyF');await pg.wait_for_timeout(330)
    R['corner [p1 x before, after, p2 x, p2 within wall]']=await ev(f"[{x0},Math.round({F}[0].x),Math.round({F}[1].x),{F}[1].x<=1490]")
    # crossover jump from close range
    await place(700,860);await pg.keyboard.down('KeyD');await pg.keyboard.press('KeyW');await pg.wait_for_timeout(950);await pg.keyboard.up('KeyD');await pg.wait_for_timeout(300)
    R['crossover [p1x,p2x,p1face,p2face,p1y]']=await ev(f"[Math.round({F}[0].x),Math.round({F}[1].x),{F}[0].face,{F}[1].face,{F}[0].y]")
    # particle cap while paused with a projectile in flight
    await place(400,1300);await pg.keyboard.press('KeyH');await pg.wait_for_timeout(300);await pg.keyboard.press('Escape')
    n1=await ev("__clash.partsCount");await pg.wait_for_timeout(2000);n2=await ev("__clash.partsCount")
    await pg.keyboard.press('Escape');R['particles while paused (before, after 2s)']=[n1,n2]
    await pg.wait_for_timeout(1500);R['errors']=errs
    await b.close()
asyncio.run(run());print(json.dumps(R,indent=0))
