// ------------------------------------------------------------ Tide water: coordinated ribbons, droplets and splashes
const WATER=(()=>{
 const RIB=[{w:4.2,ph:0,rx:78,ry:30,tilt:-.35,N:18,width:9},{w:-3.1,ph:2.1,rx:58,ry:44,tilt:.5,N:14,width:7},{w:5.6,ph:4.2,rx:96,ry:22,tilt:.1,N:12,width:5}];
 const S=new Map();
 function st(f){if(!S.has(f)){S.set(f,{t:0,rib:RIB.map(r=>({...r,th:r.ph,pts:[],dep:[]})),splashDone:null,fade:1,lastFire:-9})}return S.get(f)}
 function anchor(f){const [img,m]=sprite(f);if(!img)return {x:f.x,y:f.y-170};const sc=FH/img.height,w=img.width*sc,h=img.height*sc,flip=f.face!==f.c.native;
  const wx=m.wx??.3,wy=m.wy??.55;return {x:f.x+(wx-m.fx)*w*(flip?-1:1),y:f.y-(1-wy)*h}}
 function mode(f){if(f.ko)return 'ko';if(superFx&&superFx.f===f)return 'charge';const a=f.atk;
  if(a&&a.type==='tsunami')return a.phase==='start'?'charge':'release';
  if(a&&a.type==='special')return a.phase==='start'?'windup':'release';
  if(f.st==='hit')return 'hit';return 'idle'}
 function step(f,dt){if(f.key!=='tide')return;const s=st(f);s.t+=dt;const A=anchor(f),M=mode(f);
  s.fade=lerp(s.fade,M==='ko'?0:1,dt*3);
  const body={x:f.x,y:f.y-150};
  for(const r of s.rib){let rx=r.rx,ry=r.ry,w=r.w,cx0=A.x,cy0=A.y;
   if(M==='windup'){const k=atkK(f).k;rx*=1-.75*k;ry*=1-.75*k;w*=1+3*k;cx0+=f.face*28*k}
   if(M==='release'){const k=atkK(f);const kk=k.ph==='rec'?k.k:0;rx*=.35+.65*kk;ry*=.35+.65*kk}
   if(M==='charge'){rx=150+r.rx*.4;ry=70;w*=2.2;cx0=body.x;cy0=body.y}
   if(M==='hit'){rx*=1.5;ry*=1.5}
   r.th+=w*dt;const ct=Math.cos(r.tilt),sn=Math.sin(r.tilt);const ox=Math.cos(r.th)*rx,oy=Math.sin(r.th)*ry;
   const head={x:cx0+(ox*ct-oy*sn)*f.face,y:cy0+(ox*sn+oy*ct)};
   if(!r.pts.length){for(let j=0;j<r.N;j++){r.pts.push({...head});r.dep.push(0)}}
   const prev={...r.pts[0]};r.pts[0]=head;r.dep.unshift(Math.sin(r.th));r.dep.length=r.N;
   const follow=1-Math.pow(1-.42,dt*120);
   for(let j=1;j<r.N;j++){const p=r.pts[j],q=r.pts[j-1];p.x+=(q.x-p.x)*follow;p.y+=(q.y-p.y)*follow+18*dt*j/r.N}
   // droplets shed from the ribbon head, faster when the water whips around
   const hv={x:(head.x-prev.x)/dt,y:(head.y-prev.y)/dt},spd=Math.hypot(hv.x,hv.y);
   if(s.fade>.3)every(r,'_d',(M==='idle'?1.2:4)+spd/900,dt,()=>parts.push({x:head.x,y:head.y,vx:hv.x*.35+rnd(-40,40),vy:hv.y*.35+rnd(-120,-20),life:1.2,t:0,size:rnd(3,6),c:'#e6f8ff',grav:1000,kind:'drop'}));
  }
  if(M==='charge')every(s,'_rp',22,dt,()=>parts.push({x:f.x+rnd(-170,170),y:GROUND,vx:0,vy:0,life:.6,t:0,size:rnd(10,22),c:'#d8f6ff',grav:0,kind:'ripple'}));
  // strike splashes: one burst at the moment a punch or kick lands its active frames
  const a=f.atk;if(a&&(a.type==='punch'||a.type==='kick')&&a.phase==='act'&&s.splashDone!==a){s.splashDone=a;
   for(let k=0;k<12;k++)parts.push({x:A.x,y:A.y+rnd(-14,14),vx:f.face*rnd(180,520),vy:rnd(-360,-40),life:1,t:0,size:rnd(3,7),c:'#eefbff',grav:1100,kind:'drop'})}
 }
 function drawLayer(f,front){if(f.key!=='tide')return;const s=S.get(f);if(!s||s.fade<.02)return;const g=cx;
  g.save();g.lineCap='round';g.lineJoin='round';
  for(const r of s.rib){const P=r.pts;if(P.length<2)continue;
   for(let pass=0;pass<2;pass++)for(let j=0;j<P.length-1;j++){const d=r.dep[j]||0;if((d>=0)!==front)continue;const k=j/(P.length-1);
    const wdt=lerp(r.width,1.2,k)*(pass?.42:1);g.globalAlpha=s.fade*(pass?.9:.55)*(1-k*.6);
    g.strokeStyle=pass?'#f3fdff':'#7fd3f7';g.lineWidth=wdt;g.beginPath();g.moveTo(P[j].x,P[j].y);g.lineTo(P[j+1].x,P[j+1].y);g.stroke()}
   // a highlight that travels along the ribbon so the flow direction reads
   const hi=Math.floor((s.t*26+r.ph*3)%P.length);const d=r.dep[hi]||0;if((d>=0)===front&&P[hi]){g.globalAlpha=s.fade*.95;g.fillStyle='#ffffff';g.beginPath();g.arc(P[hi].x,P[hi].y,lerp(r.width,1.5,hi/P.length)*.45,0,7);g.fill()}}
  // forming orb during the Bubble Orb wind-up
  const A=atkK(f);if(front&&f.atk&&f.atk.type==='special'&&A&&A.ph==='start'){const an=anchor(f),R=f.c.proj.r*A.k;drawOrbBody(an.x+f.face*28*A.k,an.y,R,s.t,.9)}
  g.restore()}
 function drawOrbBody(x,y,r,t,al){const g=cx;if(r<2)return;g.save();g.globalAlpha=al;
  const sx=1+Math.sin(t*11)*.06,sy=1-Math.sin(t*11)*.06;g.translate(x,y);g.scale(sx,sy);
  const gr=g.createRadialGradient(-r*.35,-r*.4,r*.08,0,0,r);gr.addColorStop(0,'rgba(255,255,255,.95)');gr.addColorStop(.45,'rgba(150,222,252,.6)');gr.addColorStop(.92,'rgba(52,160,232,.62)');gr.addColorStop(1,'rgba(235,250,255,.95)');
  g.fillStyle=gr;g.beginPath();g.arc(0,0,r,0,7);g.fill();
  g.strokeStyle='rgba(255,255,255,.85)';g.lineCap='round';for(let k=0;k<3;k++){g.lineWidth=3-k*.7;g.beginPath();g.arc(0,0,r*(.72-k*.18),t*(7+k*3)+k*2,t*(7+k*3)+k*2+2.2);g.stroke()}
  g.restore()}
 function drawOrb(p){const g=cx;const h=GROUND-p.y;g.save();g.fillStyle=`rgba(20,6,14,${clamp(.32-h/1400,.08,.3)})`;g.beginPath();g.ellipse(p.x,GROUND+2,p.r*.9,p.r*.18,0,0,7);g.fill();g.restore();drawOrbBody(p.x,p.y,p.r,p.t,1)}
 function emitOrb(p,dt){const d=Math.sign(p.vx);every(p,'_m',34,dt,()=>parts.push({x:p.x-d*p.r*rnd(.4,.9),y:p.y+rnd(-p.r*.6,p.r*.6),vx:-p.vx*.12+rnd(-30,30),vy:rnd(-60,40),life:.9,t:0,size:rnd(3,6),c:'#dff6ff',grav:700,kind:'drop'}))}
 function burstAt(x,y,n,spd){for(let k=0;k<n;k++){const a=-Math.PI*rnd(.05,.95);const s=spd*rnd(.4,1);parts.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:1.2,t:0,size:rnd(4,9),c:k%3?'#e9fbff':'#9fe0ff',grav:1100,kind:'drop'})}
  parts.push({x,y,vx:0,vy:0,life:.4,t:0,size:30,c:'#ffffff',grav:0,kind:'ring'})}
 function waveShape(p){const d=Math.sign(p.vx),h=230*p.h,x=p.x,t=p.t,pts=[];
  for(let i=0;i<=26;i++){const u=-280+i*(400/26);const prof=u<0?Math.pow(1-(-u/280),1.6):Math.max(0,1-Math.pow(u/120,2));
   const wob=Math.sin(u*.045-t*14)*.06+Math.sin(u*.11+t*9)*.03;pts.push([x+d*u,GROUND-h*clamp(prof+wob*prof,0,1.1)])}
  return {pts,d,h,x}}
 function drawWave(p){const g=cx,{pts,d,h,x}=waveShape(p);if(h<4)return;g.save();
  const gr=g.createLinearGradient(0,GROUND-h,0,GROUND);gr.addColorStop(0,'rgba(225,250,255,.96)');gr.addColorStop(.35,'rgba(90,200,250,.88)');gr.addColorStop(1,'rgba(28,105,195,.85)');
  g.fillStyle=gr;g.beginPath();g.moveTo(pts[0][0],GROUND);for(const [a,b] of pts)g.lineTo(a,b);g.lineTo(pts[pts.length-1][0],GROUND);g.closePath();g.fill();
  // flow lines scroll backwards through the body of the wave so it reads as moving water
  g.save();g.clip();g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=3;for(let k=0;k<4;k++){const yy=GROUND-h*(.2+k*.17);g.beginPath();for(let u=-300;u<=140;u+=12){const X=x+d*u,Y=yy+Math.sin(u*.05+p.t*10+k)*6;u===-300?g.moveTo(X,Y):g.lineTo(X,Y)}g.stroke()}g.restore();
  // curling lip and foam crest
  const top=pts.reduce((m,q)=>q[1]<m[1]?q:m,pts[0]);g.strokeStyle='rgba(255,255,255,.95)';g.lineWidth=7;g.lineCap='round';
  g.beginPath();g.moveTo(top[0]-d*90,top[1]+h*.18);g.quadraticCurveTo(top[0],top[1]-10,top[0]+d*70,top[1]+h*.25);g.stroke();
  g.fillStyle='rgba(255,255,255,.9)';for(let k=0;k<6;k++){const fx=top[0]+d*(-60+k*22)+Math.sin(p.t*20+k)*4;g.beginPath();g.arc(fx,top[1]+6+Math.sin(p.t*17+k*2)*4,5+((k*7)%4),0,7);g.fill()}
  // contact line with the floor
  g.fillStyle='rgba(235,250,255,.7)';g.beginPath();g.ellipse(x-d*80,GROUND+3,190,9,0,0,7);g.fill();
  g.restore()}
 function emitWave(p,dt){const {pts,d,h,x}=waveShape(p);if(h<10)return;const top=pts.reduce((m,q)=>q[1]<m[1]?q:m,pts[0]);
  every(p,'_f',55,dt,()=>parts.push({x:top[0]+d*rnd(-30,60),y:top[1]+rnd(0,20),vx:p.vx*rnd(.3,.8),vy:rnd(-320,-80),life:1,t:0,size:rnd(4,9),c:'#ffffff',grav:1000,kind:'drop'}));
  every(p,'_t',26,dt,()=>parts.push({x:x-d*rnd(150,280),y:GROUND+rnd(-2,4),vx:p.vx*.05,vy:0,life:.9,t:0,size:rnd(14,30),c:'#e8fbff',grav:0,kind:'foam'}))}
 return {step,drawLayer,drawOrb,drawWave,emitOrb,emitWave,burstAt,reset:()=>S.clear(),_state:S}
})();
window.WATER=WATER;
