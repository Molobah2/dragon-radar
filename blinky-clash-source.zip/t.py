import asyncio,sys,json
from playwright.async_api import async_playwright
U='file:///tmp/claude-0/-home-claude/0370a9bc-09aa-5c0e-9bd4-b8c8dd3e00e9/scratchpad/fight/test.html'
async def run():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    pg=await b.new_page(viewport={'width':1280,'height':720})
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(U);await pg.wait_for_timeout(800);await pg.screenshot(path='a_menu.png')
    await pg.click('#go');await pg.wait_for_timeout(1900)
    await pg.keyboard.down('KeyD');await pg.wait_for_timeout(700);await pg.keyboard.up('KeyD')
    for k in ['KeyJ','KeyK','KeyJ','KeyL']:
      await pg.keyboard.press(k);await pg.wait_for_timeout(250)
    await pg.wait_for_timeout(100);await pg.screenshot(path='a_fight.png')
    for i in range(20):
      await pg.wait_for_timeout(1000)
      st=await pg.evaluate('JSON.stringify([__clash.state,__clash.fighters.map(f=>[Math.round(f.x),Math.round(f.hp),Math.round(f.meter),f.wins,f.st])])')
      if i%4==0:print(st)
    await pg.screenshot(path='a_late.png')
    print('errs',errs[:5])
    await b.close()
asyncio.run(run())
