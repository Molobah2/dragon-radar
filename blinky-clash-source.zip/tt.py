import asyncio, json
from playwright.async_api import async_playwright
U='file:///tmp/claude-0/-home-claude/0370a9bc-09aa-5c0e-9bd4-b8c8dd3e00e9/scratchpad/fight/test.html'
async def run():
  async with async_playwright() as p:
    b=await p.chromium.launch()
    pg=await b.new_page(viewport={'width':1600,'height':900});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(U);await pg.wait_for_timeout(400);await pg.click('#pick-tide');await pg.click('#m-duo');await pg.click('#go');await pg.wait_for_timeout(1900)
    ev=pg.evaluate;F="__clash.fighters"
    # in-page recorder: log a compact event stream every simulation-visible frame
    await ev("""(()=>{const F=__clash.fighters;window.LOG=[];let last='';const t0=performance.now();
      (function rec(){const T=F[0],E=F[1];const w=__clash.projs.find(p=>p.kind==='wave');
       const st=[__clash.superActive?'cutin':'',T.atk?T.atk.type+':'+T.atk.phase:'free',w?'wave':'nowave',E.st,E.hp,Math.sign(Math.round(E.vx))].join('|');
       if(st!==last){LOG.push([Math.round(performance.now()-t0),st]);last=st}
       if(performance.now()-t0<3500)requestAnimationFrame(rec)})()})()""")
    await ev(f"(()=>{{const F={F};F[0].meter=100;F[0].x=420;F[1].x=1050;F[1].hp=100}})()")
    await pg.keyboard.press('KeyT')
    await pg.wait_for_timeout(1180);await pg.screenshot(path='T1.png')
    await pg.wait_for_timeout(180);await pg.screenshot(path='T2.png')
    await pg.wait_for_timeout(180);await pg.screenshot(path='T3.png')
    await pg.wait_for_timeout(250);await pg.screenshot(path='T4.png')
    await pg.wait_for_timeout(1800)
    log=await ev("LOG");print('TSUNAMI LOG');[print(' ',r) for r in log]
    # knockout and results: P1 already has one round, Ember low on health
    await ev(f"(()=>{{const F={F};F.forEach(f=>{{f.atk=null;f.stun=0;f.vx=0;f.y=742;f.ground=true;f.st='idle'}});F[0].wins=1;F[0].x=900;F[1].x=1060;F[1].hp=3}})()")
    await pg.wait_for_timeout(100);await pg.keyboard.press('KeyF');await pg.wait_for_timeout(250)
    s1=await ev(f"[__clash.state,{F}[1].ko,{F}[0].hp]")
    # try to keep fighting after the K.O.: P2 kick and a P1 fireball should not do anything
    await pg.keyboard.press('Period');await ev(f"{F}[1].ko=false;{F}[1].st='idle'");await pg.keyboard.press('Period');await ev(f"{F}[1].ko=true;{F}[1].st='ko'")
    await pg.wait_for_timeout(600);s2=await ev(f"[__clash.state,{F}[0].hp]")
    await pg.wait_for_timeout(2600);s3=await ev("[__clash.state,!document.getElementById('end').hidden]")
    await pg.wait_for_timeout(1600);s4=await ev("[__clash.state,!document.getElementById('end').hidden,document.getElementById('eline').textContent]")
    print('KO',json.dumps({'after_hit':s1,'after_attempted_attacks':s2,'2.6s_later':s3,'results':s4}))
    print('errs',errs);await b.close()
asyncio.run(run())
