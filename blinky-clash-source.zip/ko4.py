import asyncio, json
from playwright.async_api import async_playwright
U='file:///tmp/claude-0/-home-claude/0370a9bc-09aa-5c0e-9bd4-b8c8dd3e00e9/scratchpad/fight/test.html'
async def run():
  async with async_playwright() as p:
    b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1280,'height':720});errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    await pg.goto(U);await pg.wait_for_timeout(400);await pg.click('#m-duo');await pg.click('#go')
    F="__clash.fighters";out={}
    async def wait_fight():
      for _ in range(80):
        if await pg.evaluate("__clash.state")=='fight':return
        await pg.wait_for_timeout(100)
    # round 1: Tide knocked out with a kick, then check the clean reset of round 2
    await wait_fight();await pg.evaluate(f"(()=>{{const F={F};F[0].x=800;F[1].x=950;F[1].hp=4;F[0].meter=60}})()");await pg.wait_for_timeout(100)
    await pg.keyboard.down('KeyG');await pg.wait_for_timeout(40);await pg.keyboard.up('KeyG')
    await pg.wait_for_timeout(300);out['round1_state']=await pg.evaluate("__clash.state")
    await wait_fight()
    out['round2_reset']=await pg.evaluate(f"""{F}.map(f=>({{x:f.x,y:f.y,vx:f.vx,vy:f.vy,face:f.face,hp:f.hp,ko:f.ko,koRot:f.koRot,st:f.st,atk:f.atk,stun:f.stun,ground:f.ground,pushT:f.pushT,koPhase:f.koPhase,wins:f.wins,meterKept:f.meter}}))""")
    out['round2_timer']=await pg.evaluate("Math.round(__clash.timer)")
    # round 2: same knockout again, this time it ends the match
    await pg.evaluate(f"(()=>{{const F={F};F[0].x=800;F[1].x=950;F[1].hp=4}})()");await pg.wait_for_timeout(100)
    await pg.keyboard.down('KeyG');await pg.wait_for_timeout(40);await pg.keyboard.up('KeyG')
    seq=[]
    for i in range(45):
      await pg.wait_for_timeout(100);seq.append(await pg.evaluate(f"[__clash.state,{F}[1].koPhase,Math.round({F}[1].y),{F}[1].ground,!document.getElementById('end').hidden,Math.round(__clash.timer*10)/10]"))
    out['round2_sequence(state,phase,y,ground,resultsCard,timer)']=[s for k,s in enumerate(seq) if k==0 or s!=seq[k-1]]
    out['results_text']=await pg.evaluate("document.getElementById('eline').textContent")
    await pg.screenshot(path='K_end.png')
    # rematch starts clean
    await pg.click('#again');await wait_fight()
    out['rematch']=await pg.evaluate(f"[{F}.map(f=>[f.wins,f.hp,f.ko,f.y,f.face]),Math.round(__clash.timer)]")
    out['errors']=errs;print(json.dumps(out,indent=0));await b.close()
asyncio.run(run())
